<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6ddbfbc0aee56bdc227d38e1031ad40a',
      'native_key' => 'core',
      'filename' => 'modNamespace/54ec57f5d6489caba0fd22d7aeb9b7b2.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '69588f858ba5a39665b0bbe76e9763f8',
      'native_key' => 1,
      'filename' => 'modWorkspace/66d311f7033de3cfa0de69985317b23b.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '9ea17493070490e5fa2c75173e922b90',
      'native_key' => 1,
      'filename' => 'modTransportProvider/161738d84fb1d71bafb14975934c1903.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4a47b6e549780c34db845418750905b8',
      'native_key' => 'topnav',
      'filename' => 'modMenu/154c5ab52aaf8ebf0d9135c1b5116fd1.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e46713b779fc2eac6b57494e4c187129',
      'native_key' => 'usernav',
      'filename' => 'modMenu/2cb66b868b33d91225f2e8325fdd2f60.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'eb5e7a8c21a90e514f87acfc3884b74d',
      'native_key' => 1,
      'filename' => 'modContentType/88fa32886b3036a610c19f105f67beb1.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b680fddd32ba01d3d1a6a02cf94c9ba8',
      'native_key' => 2,
      'filename' => 'modContentType/12987ede2702517b2df3fe9da15dcf93.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'dea8221d6b1a9a6e4f610f5a3979fc84',
      'native_key' => 3,
      'filename' => 'modContentType/b7ff7924bca642f78052c88e52c84a77.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3b31926254733c9f78253c8f37480330',
      'native_key' => 4,
      'filename' => 'modContentType/2b1430ce7c2cec2922ad69882750dcd7.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e592c1d877bf857e0373316167edc20b',
      'native_key' => 5,
      'filename' => 'modContentType/3efaa27dd8ec4dc8bdba2babe45809df.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2f5973c6da516fdd0479f1d69688bbb1',
      'native_key' => 6,
      'filename' => 'modContentType/e53d5cfb5ab0357aeb00e4c16abdd5ab.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0e225042405c580a736225544ae21fd2',
      'native_key' => 7,
      'filename' => 'modContentType/b22819f96792924b7179cfaa31f81f31.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '16ce7061e9764d6f30983ac8cba97c71',
      'native_key' => 8,
      'filename' => 'modContentType/f93df1e98cadce9fff6e0f561aa5571f.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6c1863edb8ef62e00354dc49202eab08',
      'native_key' => NULL,
      'filename' => 'modClassMap/6c6067a5f99dd2d0575ffea0c572d8ff.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '6b31a27fcb27724e8876d2808b8192aa',
      'native_key' => NULL,
      'filename' => 'modClassMap/5e50026865142a2822b14284db9e14d5.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '814fb79a296bff51fae66f72dde546cd',
      'native_key' => NULL,
      'filename' => 'modClassMap/1815148b13cf21ae8f097bd1feffcdd9.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7333efe0de482568d18a27660414ef51',
      'native_key' => NULL,
      'filename' => 'modClassMap/4c8731b059bd19bf2ef44a03c59ab75d.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8ae8a3f2989179350b190ad2c4d84aae',
      'native_key' => NULL,
      'filename' => 'modClassMap/44cbcc73629ffd1743bb8d9a6d2cf533.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b9f54fbb52d0eef61adf4bb57a087730',
      'native_key' => NULL,
      'filename' => 'modClassMap/e95015269ac591a2442478c998ec51de.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9b240dd35a60d557d93c0564064c2079',
      'native_key' => NULL,
      'filename' => 'modClassMap/7afb46ae2d58df2d8c877c90c9676423.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ab03d722aedcbfabc6fa21f6f141a957',
      'native_key' => NULL,
      'filename' => 'modClassMap/d546c4934b8fbeee2adaf47fd3d5b07d.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b8f92092d03d21deffac233e482fb28f',
      'native_key' => NULL,
      'filename' => 'modClassMap/828a11a932ef14a9003210a7d607be3d.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5518a014b3647cd29d3ac5c4c851e803',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/e1f3e19dcdce05dee00b69014b69a1e8.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16a94597b9e07b081d8fc94fe335312e',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/fff92a8da686e86dbb3cf0ff282554ae.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1ccb8e7baf48a1945969499ee50f84d',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/ff223e2360da225c21238ff7192b95d1.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e804a81b8218130b2b24ad69cd163512',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/5c4cc09279db7ec69378859fe4298c68.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12a841bc68095b8e1373070c108784db',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/056f3363fb6f36ec34f17c651d91a408.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2601d1e97135f8b6c03b86bb2ce5c741',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/89a24795be418a135aa30b877264e7b3.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae81e3cc88a74f1126d74a7c6c264ed7',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/8bef54d2f3b4424f98345358d72c7f57.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96892230269b3e3af72d48a5ea8a4de1',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/685b1856ef22ade8052fb20ada617acd.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '272962f1d6d212807550689a369b0a75',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/77bd8ffa69485a6bfc7969d127245fe5.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c98a8d996c827fecb5431d157dd97655',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/0e6426f09a7a732bbf85551629562ef9.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e62ca01450252f77cebb6aeb824f6402',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/f04897b8107d78c543835122d218b878.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4e0b5d2d9e012528eed431b4808ce1c',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/7e207ede0a7c5851473ee934212edb95.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd9687f51795c31d6bdccf49ab05a214',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/1d1e5b0cb8beedf852b3f79d67fa74ad.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1632577b50b72e43354d06aabb840a76',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/8974b084a2ab463fe46c068bfae5ed02.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '192213ba1b7a48602fd6f6d92ecb523f',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/fa751f6f5a05c31c70986e14f942fa19.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ce3b40075157e97457189ee41431c23',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/dd8e9e39f51d3edb7c2d6d519dd8b51f.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '835803574641bfc4327a556214badbb2',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/184af33537e784c39c007d5ea51289e6.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '971c9ea14c2c003e1944f05f4462b2ed',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/4e0de0c190c80c80fb1bb6380a472f5f.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03d1d56adafb4bde90f1e6734e91f2e1',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/e289f494ac6f5989c2e1ab22f4d9c988.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '244e49a0b4015c3a9d518f513f0b3f1c',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/727a8371751723268ec20b0b916d01c9.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83c2d4110054d61f5c72cc3c2ebf133a',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/9f10161f724bac32766e9cf267ed91a7.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9437a20dae5217bc51583d611d3d61d',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/cf8ce02273eacbe0a47251497b21c2c7.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6918d8239e7de30a0153e0ee676561c3',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/03da79bd854d750766f30ee662baa167.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f4bb3d44079048b988a84b90d0c1d45',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/a352f8e47e41c40b1588fd0dd5aee4ea.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c45e36993aaefd9c3a1499c3f4d8e92',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/b4c102765026255e83af98fef53f4320.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2095a3ea6b78c5b27d8eaf84fc8a620',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/213629160df06216830bb49fbc73d9b2.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '510d51390c4ebfbdc5115266292eab1a',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/edb9328c3493fc23f03920b7d0e113ec.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4b6c805e2ac5d7d9f718231b3f4e26a',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/37f13255b723e698b5fd54a7a727b707.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bf727f0efadb7f9ae2a2ca29a0ef0f4',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/8781b99a6213479c240aade37bad3990.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a59e44c8aa7cb0e15c4931c9971cc01',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/90b906542cff32ce320364291d369838.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cd24099e64ffde19476eeca2b3eeeb7',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/b32e00a44f8bb58194e0ba0fde42ed38.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67b2c42ed3fdca462680b48fa7ac68bc',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/99771711e655587c0cea1eeba334de09.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95e08cbfa87b20b8203f11dc234758b7',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/58e3220a1df1b6b179abe997a0968341.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dc53312c1eff63f4e381229920d8ce8',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/a55b2749acb334edf343bf6f7c3d53ac.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9348d4a93289039d8ff45f04996d387',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/1600e71ae058c88b010a82f6ccc02002.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a36af0dc65ece3ea34c52d1049d7b50e',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/f2653300fb065d2e305f32df35acfac2.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06d7afeb4e76ccbdfbd13915fa2623ef',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/e9be7e6dd26db9de9bb27e3eb436cada.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a1b8319747529e3c092775b267105cd',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/e6527d73aa02dd4e761bf3fc14527d4f.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51b00119b6930c7cd1d06a0848167acc',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/5ca71e9996edb46fe2a949e6eff5b2b6.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6421ff04b1970724b99bdd121e8d0d4d',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/e568a7b704dffc1fda5654ce1aff0a8a.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55813ebad4100ef3ef3978a258e86a56',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/2904fe7d6142c9e13f92d0a125559899.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81edda1cfe166b619b440fedd08b3d34',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/a5818ae008bbb69e0b59ee340cc28d71.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb399e805a9ec48320f939fbe1b04c9f',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/b6f2ccfa459d0630c255de39ad4efad9.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef4a46db6d975d0a8d7cddb3f5892760',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/f97ee1658db69fd5882a7a8656a0314c.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0167ad8f479d757a134e7ca726f7b7bc',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/c08f99ab17b5577b9602a9d9e4d919f3.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1969d1615269f02bf9e7e6d77eeff19',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/4897082083d038981647c3e41e74e6fa.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5db214e332de92bcbc45669be03b0eba',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/efb386adf3371093d689a4918f7d7d9d.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5be157ec8fe252f043bad8364d6dc462',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/f2ea2f80d9489ef229aa806ad600943a.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c28a7be8b83e3fa66de792605f950a8e',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/211abd1534aa7ee098d4bb6b3f5e9cfa.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86fe6fd71749db1f66bd15dd70d80836',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/0afa7b41e6832d0d83d7682d312965ce.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '347f5d06a036a143e93e4021b3c34b91',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/95c0c2a29b4eea031b67c5b0b5ed8b50.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96e1f2862b452b76ba83bc0223c888a2',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/fcdfd79b93dc3a6bf71e9195547121c3.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b37ee696143bfcdb8b93225af548c1f',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/4a59aa65af345b225cadf999d9b81eda.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fee291ee3c89c68b0325d7a51ea955ad',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/972e5919d2605b417be14c22f3d5b0c5.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6c030e6dc5dec9866acd618b06fb0d9',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/06cb4e6892cb4c2ffa0f665b8c5be263.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78de5fb4d2e3ab827f6039c5f3807d7a',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/b447087b55538c615866003219e1c045.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b39f868502d07654afbcca0baf272b65',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/6c491539d4a4c59edfb335f8040de8e7.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aca704a83a449a4065edb3d724802ee3',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/8e28346af391bc53d58d3d28fe6467d7.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f41407cf553ae2cd265b2fdfb1bc348',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/91596f1d6af598dbffbd4df011e95ceb.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '737cf70028603ab3d1f4d8d50ed7ee58',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/bb7df49a97d58e2002c34f2dc3b0d7df.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fedc6276091d77485c0fc75bad387843',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/19e05d596a14f55a534856453c74cc3d.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a190483977d0828293e5781201eb7557',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/c83516d850f9168548f08919998a64f3.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82ef95d5438e1d5b938339215f6d8d2d',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/72b94547fd0a816d7df4c29e022f830e.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2852bce71d54ee4e86037ac8ee5359d7',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/5d50a4288fb5ffa968fc7635740d255c.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '066ed177894731e53e08849356731672',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/4e31a8d1f38a66a01f51d5551d4f98d3.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c9dfd4c9b1d212b73365da93ffcd81d',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/440f0bb2f908d1f162b276740848f195.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6ae31b758383dc73087e74706aa6b84',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/9d2ca8da5aa37849c7222770d63b9e6b.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05f9bbe8748444aa9b4ebfbced5fff92',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/f41f1074606cdf3524290181e032c932.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '732dbf1c5252cbb16b1c04524b1cf654',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/96138e869682f4791ad4e22545ceec02.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0c724747690ea5f567b49bcb91d5dcd',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/b97626d459aa94459b5b4e6c1d94db6f.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9981818a891020b5327d86868378e50e',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/0116b1ba1346d48d43a2a4b62cf98b8a.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '242e90dce8909a54c5ca4f437aaeed0a',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/54a588ea25ca2238088d95b1923c34b1.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0aaf10e929424d69453d5ab37e2eab1d',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/2902c53bf15e85d50f2d2f0b49bc577e.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '452c2bf52d26ad7313674bd5d4b04a82',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/bbcee6b033f5b2b6382c994da6fe523d.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6eaeceaa9c609f43470e3949f1af953d',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/40fa53fdc676a8475b4419f06957afd6.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0be8d8fee93287c5f1ca3f9a038eaced',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/bd0c204138b18f16dcce090700029715.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c64c1c7283ff773aae7bfa1bdd12288f',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/1f8af1024dca705f1652da3882296136.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f009124c26ad0da521dbf01d19a73d9',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/538897688d8c0bcec6217311e6847acc.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa9f21072776d49b79212aed4edae001',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/6c714bc6aedcca7dcb635c048ee30fa4.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0d2b8accfb63d03d0b8d1e5b2ff723f',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/7edc67f9f74aeb7d05b2f8f933c1ebd8.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8afa316b03f44b8911381d6f67cc4475',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/3afba0800b95776546e150182f86147d.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a070d13dd54716e91d49ade1e2094db5',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/11ddf0b7a9c0c0bf07d77990eef7938c.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e95d765f122ad5d53b5739269232538',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/1f6d675173dd5b53c5dc1f45f6156424.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca880ea63a296be34d43e50b158e81d4',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/4678ed653956db8b9b395c8e41f03057.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e58832bfb1e8eef7c9635d0bcee8fe4',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/ca0ca0f9ab239d1fb6c4007d4bfd6191.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b65b79cdee7c3e956dc5687bbcdb4424',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/5a789b0914e78004fe2824852a0c0426.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47fa53983fc994a3ff58edcf26817c3c',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/b0e2d90d9d7bc72e35abb893ee53144f.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef63f2f4c0497745d0902285cef330a1',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/19a26114e91e99cbaeaafd34dba72dea.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8030fdab9bafacb1eaafe7ef9c822301',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/ced573d888bbba279bc9e24239881af4.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa8613bc6553018b5e113c45ea15d58a',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/a48bddd25072960fd7e725328bc9a762.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b46994225f8c66e64fd6625eccfefe44',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/c07cb571cc078c48384a39688d33e2ec.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02d9cc005bb930e46119229d7935516e',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/189732d935370d7c783fff8bf83fdaf1.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '876ffd47f9a08b4f35d81d316665ffeb',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/77f845f333c84ab2a406efebca1e610d.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e046c3d93814f9e962d002f611eff2a9',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/617403aa50ed91be1b151795cde85ec0.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '767faa16f5c51180e89e5ddae48795e2',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/595a05397c220c5982365e3d1bdf75f4.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fcb7c0f93eff47a1fb3ca92af517760',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/b1e2700a9fcc9f0fa58db7eb9b0edb50.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39616c73a24fe7a4b6b221958aff1281',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/821855acd15df7e7bad9204ea2070894.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2f1d5e0c7203dedb81074516053e809',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/2cb19316b101296743b9f15201ab9851.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a33fbe21203898675c0c60263bad7163',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/29a4cbb1aa078c8f72425154997c0a6a.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '968cf3697af891a66a0b2a2517ecfbe8',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/3b939070a34af1445a1d74dc4dbb1a1b.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '597fede005897b59a6670e136e8f46a6',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/2f71e60db59e2fe05ef1d089a179e9f2.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ad9ceeabb53aee91e203f6e6449cc77',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/85c8c52317bc374c25550a5c05cb900a.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd61c0206d6368731cda22f8be59f2d4c',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/2ade378ea98e62574eac25113856d1e4.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a49acfe1b33f9864a9aaa5b9c240b82',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/0c0c98c97344705807df2f1f8a8a8ba3.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24bb958db47af6cb1301c7ebe4b0a471',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/6fea2f7c1e7d92096f9a28453f4650eb.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ff8a43f237938349ae766b509b298f3',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/a740de1dc1b6521acda0d879b99fb6d4.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6004386bddb004f554e8bf6cbca395a',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/bd63461482365ae7de6afe23003c6da0.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc78bd5cce11fd7a1082a79cd9342eb5',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/5f10c13b570d8d625d1f9036d6ba090b.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22deaa91300a0d260e88cbc30d25fbd2',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/ded2ae4171305b7d655e0135f7c9771a.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7fca78710278429d851421618690d7c',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/dbd4e0525875ca09392818a5f5e19895.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdc60494ba08bd1855686071c568d238',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/bdd2b6fbf7fc28b10aaa055c0a63d04c.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a539fc59b491ece0b4efb5938962e37a',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/7f60e91b3490c07da5028eb622331e81.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9189cab9aa0e99b98f63f96c292d8f10',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/f84e36a1e8fce2296904c98c87b75f61.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a79dd29333ded6f5756a28a556c511b1',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/8ef4912fad772118bbf5099edfc20333.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31ac4b1fbcc97f02bc5763ef354e498a',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/3dc3e561741d4381e4ecd8eae6f8e7ab.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e723a1ad5289b0f49602207b2145645f',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/a1844bfa8f69047d1b2baf4d432080a6.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d3f85617ef999a5d68da5ab4c788744',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/54e6dd40460f165b5fcb21caf86a449b.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7285b500a3d977a4f255d7d555ca1d1e',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/bd8a996ab206633c87ce438367b6ffd7.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96d92ef6e9df24039566adb54ddd09b5',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/542be804ba9a5fcb41094141765b7408.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa41caf11b1765d95e8f1bc2685f7ef5',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/744648e02b081b22889fc97c1fd6320a.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21217870ad0a58df31f42f4ea9cc9249',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/029b2137f4b385737420405e9aa35ffa.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec0e1cc93d7be413c4e060f7037ba761',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/468ee734e2665fe19c6240940cc5d11f.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4e7c214625cdc26a1a68245dad789aa',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/e4823b6b0e3ec96691005660496c5ab0.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3699301127d4cec8dbde9ac6fb99c0ee',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/51749ed5908be294c129d326c3bab1ac.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13e9e6ea83f5e29c26e51e095919a7da',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/effabc7607dffd7f547278692fcb82de.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8f8445d8ddf70fd91d957c14c8c8edd',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/04610e48b527d7c81ed45bede87485d1.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c81d854be959aac69318f204079a46ae',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/a84a1a5739a87d3021017cdd1ee239d7.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd705aafe82184d79236c39f0188b5d8',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/04500a93a4370a281dc2064b9417c0b7.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd262dee8d2bdde40a04de92f87d402c5',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/9e7cf5adfbd71022fa30dca03e16f418.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '703ed6a1db5f288caf4105924e97a18a',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/7ee43ac2325b6117ae2c0e48405102bd.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68d6aa5a3f7b29cd5acc9ec422173911',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/c5674cb752885fb23e12f7b2c410e5b4.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '506ba8990a9b264a044f1edf31ddcfb0',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/f41b6214d2e401b7f91bc9f7758d22d0.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f872b79e3cb70ce8bdcb22e80c0ea3b',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/4b1468c533d0c056b205402e01cc8bd2.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '261e3ae0dce6d08a4074c7d651face7e',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/c73795203da7bd1b90866cb87b039726.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '677d62431682abe24aca93dfb28a4e13',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/e9f25ae2798a86b4969003e079768568.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '366bea3ac2db30d558837deab2be8b99',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/f8b26fc5fbcc506e96b1e76ab3f50494.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3fadce6b8bf5516c1689593cd6cccdc',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/0049b9713946de544dca3e1ffa82427d.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57faf69970b621a39a744e607212fe93',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/3884a4685b76848ece2eb0b0c9b39817.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5db63accd110fd0066d3a6b60b74704',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/8e80a3a0a84f60681c4c568d23277678.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '788ae00b6e61341209a9ab1bc1808855',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/433b554dccb0423ef66f3bd7c6d32d17.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be8d2dc0d709f99ccf5a5dabc6ba997b',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/4d4c72add000761d2a59647e3f151fac.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '864f525abfee28358c5b23c1316ff422',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/a433fbdea498e0c34f1adb33ab72790d.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1c19822f6b95a98034b8e39c26f4974',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/3da4b60beba16b253f1e675de5d4f760.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e32791ff4b99da853f73c7c6efa9eeca',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/29a71e41942786a2601e47bfb68a0180.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ffee2bfc4733098a2eb53a026c4942c',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/aafd13ebff4be5e9e84818f9015d2869.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2be8eebf0c81bdf1f36ca7d56daaa9e4',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/a20d6eaa2a353c2f49700df00e02785c.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd84ad04d9b2dbfa535cc7e573dc68ab6',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/8479dbd35fed96c84dc6c0621a08b469.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3933eafc8d0d05f133b93cb1658f93e2',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/e4489224744cf05e7b3b1bcd032a6b0f.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdde26ef358491d86326c935cec20075',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/ddcfbb182a5285a2ab7b4a673a7abeef.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78d3aa6195a24baa6e0d71f77dd827de',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/1cd1a92078ebb5c1029a4819211c5633.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23f0deeb29ba9e4ea96284e5f5dedc04',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/46d02d9d408ae9fb80708cb34f531f4e.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e47de944b4b4d417d96d96378ad7e33',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/d3b7375d15a12679f2570928cae61ab6.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5da99291a3d3787623bc3ac283bfa431',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/96f179bbf72bee5071cb5b0a0a97e946.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76b4f11dcc3417d86711dbfe2ede7520',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/9b59dceb9fe76d139e143da3bbbcd3c9.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '992afff81891c795503c8e4a804d259c',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/35251a04c727974e5759e15daadc89cc.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '750d888459563487ab06676f5d1ed088',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/86a4d289cc22f12f6ac60d0a58582c7e.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '111d43b2dd1f4936e2cc55b81446895b',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/22a52f356cbd117a0838f56e49a183e3.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e9f8a2928db5625eb4012fab8ed9c6f',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/93d58d787fe80a531527db145cec08d6.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b19dda455ff2319379ec9de8c085fe43',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/31818c6ffba0684c63812af836924afb.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4aae8c9a5c1ea76dc1057e4c1da3ef4',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/2ff30828c9a6207a7ed1c91eee7d70ec.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e308dbf665e3a31a25d8e7ff04913262',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/be8e93ce5210b1fcf2fe4e71c5b6ece5.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '713a4186c449eb9cd8316b15e5299932',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/aedad73067b83a23c40550ff2e8c42b7.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93922bdef7ab8ccd63a0043fc7839583',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/0992752ae7dd8b498d5ddece6910cf36.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e01a4d9c566609aac54ef76c983b748',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/fb98c97dd484b794fdd3ff10a9bd9794.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '630b85c6be37c40b042a54be472374b3',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/3c56a0d8d26e1210ca25e2f82e70d485.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e426d520acd669dd0f40db30996a056f',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/739dbd502f0783324102ed11e813e1f6.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9926968619479cb6347ad4ca186ef6c0',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/bda0b93f2729d1d930f0665af241962e.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9aee64bdd7c59811a223658b0cd347e',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/700c6a28bbd11a1ac5d5750a3e347a5c.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f9392bf796d6e6fe7ac3741ed36b89c',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/de5e6ebff09b480a586ba1d6cc41fd0b.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd028afe23e3138747f74046c224d43a6',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/3c1202c44735641b613a4f43b8e03a0c.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40d0c00674b023eb2a1fabb4d8259f19',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/e9888c628ac831a08e10b8fe628e2dce.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb41c0eebd8244be5319f1aa77ec91ac',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/7d761b3d4d4f5fd7ae8d5f28d794f679.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a373d682f576ce001845d88e31d368bb',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/6bd0ebc82e1a53a5457bd6e99b3bc07f.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3c70a7102badaa6415a0040ce3a7bce',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/81290c5888ccab87c16d2eeed66b8c32.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae6c1e673a8fc5de4545c06e3e7f9ab6',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/09220aedb509a6942401d25be443b83e.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df41e2c091d8d9f56729b00d00fbd8eb',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/853b431913bd84bf5b202ace68094a4b.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94e4d70e3ebb2237e8ec26b804fa033d',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/2ae7b01497f22b782b87cdd5d4a1ab81.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e08ade5c8cf2a6d9e3e3fae0a34a8730',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/fca33b9fa54eb19e274bfbb0be6b23e2.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23670f619e67b41dbf58de9fd46c43fe',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/50f341225855e1a3c91427b197c2e803.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73ad0b5bd1aa6b53992c177c0be62ed3',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/2abeeef34899103d06ff53884df0ee9d.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ddb9ad22e44528a4792293f923131b8',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/bc900808c58d188995d190a6a706dbbd.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f5b137af89a05ff7cba84173f886366',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/3908bfd8b935d564ab9d81b678d94e94.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb472b4cfe2bee724f52169f6546f410',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/d2e96aff5f46ce75c62f33927ac4e4d8.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7aa96d5e738498f894b09647736feb99',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/14e9e4d33e5b443ad18adde65c810867.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7f44901f750d7cbec3e1244e2291080',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/1639dc92e6a58bad4f24ca07bf1cb4ec.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be0b73ac0c4b21c433e4b7b3d22dcec8',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/62fce2ec8b41ebee4a28b69a54e4317c.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3882160e73b4ec5c27a47e1b8ea9bff',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/2272b3b37bdfa5a0af9de369e7abbb32.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c58ee260133cb8061c0a90c56b9a1857',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/50b6010b775e733f1a0d6026526f3d45.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81eadd624d2113874a30ea2637102676',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/46cec1742605648387375d8227ca6d7e.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07aa977db6b521b9b34767e9df53f2c1',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/a2d407110ba38e81015b82b8acc07808.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d6f99d5de734b35ac24712bfd3537ee',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/31c903c805c79f10c2d227d26d13fa5d.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34e2f5f16de971f624c6f18e80f299de',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/03f924fa83505379b6359bfaba975313.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b1a4c92b8c26b3765bff17eeed14aa0',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/1da2f5e910e2ec4cbda7754034ad642c.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3fee860a1f56b8f93d48517d28cff70',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/f5560056a5a6385e13a4ad7ff3a1a505.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe0832cc24c7ed19db918b8477f24eaa',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/c7c0df2332df35054745c0464cf524b9.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fccf71cbe4f8e9a7f9bd6f65169ad96',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/faab3eb3bd5079cccc5cae451996d5fc.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66834024b0b4e91c473f1a1d1fbefff7',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/0632d9e07fc36a38bf379d5d939e94f3.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f934deb2ffded1b4d961329f08db6cc',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/6d278fca5922a573e08f1d1772557dd2.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2548da5a85af1e095b30ffa16cb8585',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/c67d1166f1864e26a7dadea13a3af4f6.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5116a986bf77f0b449a56fbe54148aa6',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/d323d0b5643a29a680a04087c15dc4d7.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d0c1f3590cd790a7ff80c25e0a65dfb',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/8e26e2595e4c9008e2b7b93cee3dd5b6.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39081bc8c721a2bd50eca1c6b3929fe7',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/7a5606909481facff070d77ec09d6dcd.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84058647713cf39f89a920ce3dc0e3ea',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/5d2e80bd3a3bd0722449006c880d82c2.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd8db31e1c476b572cd13df9a21949a5',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/875a26617fcdd3cb7bf1d0138cd122b4.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6a6e1bddc72bae907b07c3503eaa6f7',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/343bca902604f6b9b49da56d203274b9.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd854d547b1cdda8e240d059df7a9077',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/b30b9bde31dbb5b5249aaa5bb9ebf5b4.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeddd5ec7fbbb81dc804d63d0f462ad1',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/1f8deed6d02097b2fe53fc760f5b21ff.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02a2e74e1b5d59ebdf98f94b09047728',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/a0275050f5f972e1dfc60b96a566c8c9.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a454eff9ed1f649f5ff8be9f21aca192',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/4a78806dcabf3f4d181c1a29363de3e5.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e944ed02e4c5c7387397ffe454812cdc',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/ae2178f5aca955038af698f7ab6d0ef0.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cc30292e740b6ff1a9c941a428c6ec3',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/fadfd748485127391af902e29ab3a5ee.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8154228395a02f4ac515b10a369e921c',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/9a7a18fbcf7f60825e55275c5298c3a9.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37802f910feadc975a250f6bba6d801e',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/76ed7da520270db980ccccfa8b59ac68.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1aaf4a5770691badff577519a5f35189',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/54b539b68ec6aa9388924c8c9e3586b8.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd40d1d01dc49d6861950fd085a9646f',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/039551857d30bb664a9564d296484342.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e44e4ecc2105c5b287b430a90ce22fa',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/02634f175b3f5cb3566e677971207624.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97b07f275173682a0cba922fa2e9da14',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/d0c10da206b35f14090cee6cb36449db.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0df4f23bd37a62d653c1dac04ba0408',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/aefca339559f33e82a00ce2947388c56.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4889aebb5aeff91f1f93c6b255d03d4a',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/15805ad7fdaf6175d164672f74cadfff.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f182b0e353399c400e1f6726d97d8e67',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/c48d043591e99b41b0271a947ca51cb1.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7bd5dde07ec128550934141c3d03609',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/f0e3af806a04f9a79712f72ed4142ab7.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df15e35036a13acb8ac803c835ec1b6d',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/07a797d4bb16de6beb3e7ca66e1144d4.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3869254b91b2abb19fad263792775371',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/7294d4fc1d4a52fc3a8d3f0b8919c165.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c42d021866f0c007073b73cc4f39c0ec',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/897591c1a072479f89e6731e51a7a881.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26b1595b7ee59b52e199f14a24587ff7',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/b5847672461ed39e2d45206b1cc83457.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90477e6d757df1ebbb47923b0e19a9af',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/01ab012b8d93397d1c8cccbfe0e2fcdb.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88927ac3413ee49f2d8923ddd5f85e76',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/97355fc86994d90e5f304e3c75d45b32.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e0df7f777821df99b93411d02ddabab',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/98f00ae1061f93bb140d30fb72c9d04c.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48f05de0ea5dbaddfac0d544f7df6d07',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/ca09bee60c5af2ceea30c949429819b9.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebd711c8ed760ace5b49048bac83e456',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/6e37ebe64ab2e9e69e3005a73fc99854.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc55f48180ee6f07c1fce15a33efbc98',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/462084f456a92e8c7eead8d4ef297714.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9256c807cfe72f6e462305d995b9637e',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/36293c0f9fbddbed9f5c8f08315c97f3.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0645d2d20be93088c6d9cf29cac81435',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/40d5022c0c8913950269b007830a6f78.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '045ec166f7cf4a3b9eca81823beab2c3',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/2d2c7f4f87ddacc4218c53150cc03cb2.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f05fa4e0309b2151041fb833ea3fc4cb',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/be60a9c961943e51ffe32d563a290aba.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '973d2a7a83221f28a78ee0ccc7b02544',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/4a3436427b004a8021262ea36962026c.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '121e3f3987d47241c0be845e48c40240',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/e4612e0499afc7de551fb50c304b9a84.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fe417051261ecd3fcab542b92e25413',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/e64ebbc129bddb333b96c596c89e249b.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11e31359d3554cea4e6fef21873132f9',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/149c94b01b55b1785b52803ff0ddab97.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e46bbb8312e6163b1c08704ec6ce17',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/16fb8557e4b73841af4d7da0f31df4da.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8af355bb6ce12d15fa48bb32fc38d9d',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/3913dff7f6d60b0a4a7a3a45988381ae.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbad9ca07c069941a120c7744025135a',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/81e3c914f3270728557849aaf5551349.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44bf2ea274c8f21047291a3a4ca0ebc0',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/2d87c404eaccc398c288a4da4be813b2.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3a612a8be305c56bf65bd091881a71a',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/3b677329ffa7a000a9642d4527ea896c.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38793ff58999c916f40b2faf42624cb7',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/603099b36d4dfa3900cf5c8369dcf9b7.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0c7c7edf9e9c6ccaed75ba79ce25150',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/26aacdec14206f677e3c6b7cf74d74d6.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fb768709ea3d14bd2ed4c0f67eb42d8',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/f072cc074bc0a5d41b68f5a417d90014.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69474d471b68962d6bcb67c5b6004993',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/1fd5330f0eaaff4ce3af758b8a029efd.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28075e438f63ea8baed5de4af7104daa',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/de50ba109a2202c0dd08be664de5fe9d.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aba21b88eee0b432b1be47f7c6cacd7c',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/64796c690db9b1973eb4ee08be961b20.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fabc47270dfaa88c9f8a7a0bc07c72bf',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/2f91e3127f013fd6baa70b1572fde8c5.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beecc3a0ff232e4ae81cb711e1c8c495',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/cd21c496bccffbc744d49ce44c4bafe8.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3220cb640e41bcb3a77b0be02a838bc7',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/746f917fb12afd7c838a261b8b418429.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dc05fffa84a8d5f3debcbeb0205a980',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/a029182d2a50ebc2d39df97801bd1b71.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a78d34bc0c0c21c7bee81f5a6144231b',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/d67668fbe8490f4df6a05dd3ff8edd5f.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddd313281f243d06d6585b0aeaf906d4',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/aed1f783df626f7b995f8e896b0d213c.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eba91e2fbd80e8fc680d2cbcef2bff1',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/7747f12e683457598edcb90f00dfde53.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c77c86691085af4fbaa634bacead0dd7',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/dfc478032f3afe2b8a53e3020986294b.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba5a0a1955c468d9a970a13304cdbd7c',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/2808672f1adab4ef201679b475d0c375.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0695b520c13f3fb66e090e16d73b66c',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/d15bda9e296204ff5b58caae3a2d27e8.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c396f959e2a137e6beeb60196915c30c',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/1900142f681c93ec950de16c803de053.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7cd2276be90cb036b0f1dbf896e1d72',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/9d6c77419e49cb4082641b4f0b43d580.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db60c78c0872b91b3dddbc94e8f1083c',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/6343beebd2fe9dfa6d0769e06a305f64.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03f06a3fe9e2c65c7483b12569d083bc',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/561d56c864f92585aafa31fbb06e7781.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7174d65f55863ab22551986613b9ecd1',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/d54ae588ecd6f4c9788edff69c5e3428.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55d9e7668fbafa927daf315ff74453e6',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/5035e4f3af17ee13eb97ec6573ed0f95.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '501978f7b03595db2dee9ece3078c3b8',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/ba08614cd0edca286a8ef6be025d185e.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b18bf2b4cad6568d1d20b530ca4d3716',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/19e33380e3b3083e937b9f7348ce3843.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aa72a7e0ce6ac3107a6d9a8280deadd',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/e5405eba6a3baee5761fc697b6bb1943.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05d1c04bc8483b115a927d97d813512a',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/c19fe3d79af085c24cfcf821a40fde18.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '584ef72dfe00c2bf9e8613bc5f3d458f',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/d9f167dcb5b88f5ae083e50b13e76891.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de0fa00e74aeba4d4432003a3698920d',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/67940649dc886735114e99c6d9507868.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '370d91b56265004d52f60d68ebb71001',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/4c6b425083ffb76a8beb91ede7ae7eec.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f05a6ec57ab12ec68166fba8cdfdd7df',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/9e11e3eaad576eb9456cadb81ead1d8e.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d180526f0aa6f1a2ca10831768238b6',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/0ac0ed970edf3934ceabb8e42438dda1.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09081517aeb069ac0ba6554fae2aec58',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/a2b9c19b6ebc010b6fe88d5a051cb013.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6a7d9e21bf4b38509e247e0220403af',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/128633a34fd8481d0a25135c30f37989.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51d6b68c07fb44c00f38595f8e03d629',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/9f265316957bde700c6637a1e3997036.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8cdc052cbaf684c9f19dada54ffe30a',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/633e3cd384aaffa058f1d0bd1e57fb61.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20321c20013d850cf2a5e7790d078919',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/e3c74d0571781f68aedfa7279934d17d.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e12d441898350d54ebb160394124a282',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/b6f9f9b76263bc949484083dd8d22761.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7207f5c5fa2a4648e6f24b934ca035d7',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/1e12cc010c48ee7d264fd45e858c7639.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e88aead547a6310a9512c95a6f0ccea',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/c4e5bddbf263d6c6da1031402f09f96b.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d7ee2adaff329583701da90b0a42a7a',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/6377954fff977e75a19c9ae3a0482b50.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e318440d7996c3645fdcc1e5adf3d1fd',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/b125cad54fdcdc5a472360a004863922.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce6e3835efc9f5cb91d7bdb03837f77a',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/5a52ee699a1d9de563a4f3ff77a8751f.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e64bc615e3a2ac552e8f7aeac102a6e',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/54e6cea85072883f1f5adf428c809c00.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88f5d3bd892ef17f6cbe38b6997ee6c1',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/94a02bd3a8239a62cd5f41bb7019fa29.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '316d584cfd142c4a2742c6e577584633',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/42d07eefc567b56fe05216d15339088c.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c76e6ce80ad6872b9399207d6499d2d9',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/4de7a29cf86ac1494d8f0ce20a91fcbf.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6a60b94875531d5f49d53a6dd6a47a2',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/2630907f964d6f1b5f41481b3f4eb8b3.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1a0131f401c52e3fbea0229d3902fd1',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/abfd6929a1d77fb78489ad1cc6b65229.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f852ffc0377a14e485df4280c2ee683',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/7212b14d67469f1cd836d82757208ebd.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f25809cda41a68f63f66951090fa99d',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/8eeb4f17791a183620682ee1e9eb81c7.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8d696fd28a76224a0929c71d7f98dc3',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/b51eced8b0c5eb5abc47dd9c40da8c22.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce31d465c1531c20c0a63224b7152f3b',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/2a2fde573127b5609fb26d4c00678f9c.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9298cc2413940dc7aa3d4060285945da',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/96480a765127e0b71b6708f07f833802.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80ea2acff804a075529ca400781a3948',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/3a4b53667b9cbe5e561b86b2933d1af8.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '436db3c7d48c730a5d9fc30d3b71f01a',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/43fa0457554e7e723b158d25735e9880.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd91ae4a62d4666ec1ce0b09403562ca7',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/76516432028af192ada0536315010d51.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5e901c7ed8154efb6a3ef951b243fd3',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/1e29e8de4dd807502113d7941df4102a.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c779aa0d1ab5a2823da100efc900a33',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/da0d87dc2a019bb3573e7c36467f3929.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d0ed395d8900b6822e91897d950151d',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/9f2f9399f350cfa4c92d2161a612d839.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fb53c746f4fd542ba2f4a0c2700b7d7',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/341cb6fdb5284b0f5d4e484090030d58.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cd849eac13cfa1f28598d3f7deeffe9',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/4b3a22e740951abcffba609d72fc5592.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af4f21f434270a6aaf589eee59625af6',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/e97b1bec696b7591a08f798c2c8e3b9c.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0e2cf31658b9717310b964f802d9ef5',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/2e38bca820bc59a6048aec23a25f6fde.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f348a701b4d7020f187b30a56023f81b',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/bf29ff31d1b8722d1752907971c3eff1.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3379c4d727cd595f8b317a0ce4e518e0',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/0a9e5f72bd8b83af0a25e05152c188bd.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76df06186bb18803b1487480d484f833',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/d5445e39f10d7eb13874123e97646f07.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d70933a99651d696495dac3bfb33ff5',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/2b63e0cb54a38f31b7731d951ae7607f.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66000c22353e5ec54d62652b62954036',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/4f894b5c250aced65f56fc6a62625e6b.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da954cba9a088b6b5acb10e035af3fda',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/622a9af8c125ff229a162dab6c54b529.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '263db514daa117e4dbe618238674fbf5',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/96d1cf7f1eede9e84793f34be853cb01.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f39fde1d824c58a2f89190c879968cea',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/c5e9133d0a52e9c2b4aceb822ce2dc70.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7923eb325cbe0726ce8886a0593e8542',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/e70e8933b86284a1c4d982643941c2b9.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7718fbf40fec439cc376abdc4022768c',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/1e911dde8524426d7dfe12042b0a0406.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29779cb9d59fff622652acfca71c344d',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/385b91d1485a8a80f763b17276282c6a.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '167aa46b24159d636b0a7a6e889124c6',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/72cc4a392a05739e2658b02def4ed3ea.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fbc582c580d999c602b4a3b520f689b',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/c1929b3a3da74b35c2a0aa4d70c65541.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84a196b2dfbf31989ff334397d306070',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/f205c5c7810dbddeb0e00eb5c9a9681b.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac91bf62cbade83d4a2ec53b6a8bc668',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/7c3258268cb45395a7980d4291fad4c4.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '868bd194419ff778fb35edf6e7ef65da',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/6abfea5ef31ef9f52dca76112e040901.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6664b66679462534366aa63c8ab2238',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/6d39c3a4e3daf650820710e9a3d5f008.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89231085161a507eb2fd6bfc23c6e8de',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/94311aa5039d28f783e6724e3ec9e605.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8669ee2c058dc947878a6a6d09c38185',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/ead0322beaf7461954671d2780b36a02.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61dbfa544878a9959a2df501575fe457',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/b9e56507df0028610534a83471894a57.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e5d930888bcd871d10b0b2a44bc705b',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/f30dfc4a5f0a8265f0b57b4b65602c55.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75e0a890c68dc3cc78d14e030929b99b',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/6cb742eb12113067da52f6bc4d8a182d.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1820c47af83bcb47d8b552c8e50e10d',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/c53ef0728f1b481abe24e25db770505b.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7b5bc4e91bc3f74e509705583b998fb',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/08988f90a72bf43a61d1a8b1f2c6bfc2.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b395c4f464d4836f5797452ce22c8e8',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/a773e6fcd18d994b767c269f2781f188.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b0769d5b4a6c7c725ecb4a86fafbcf4',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/c5d57fee96698e1ffa3ae570ac0346df.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '040bcd45fa7ccd137e438a71f84e4f7a',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/8d4a9d8b2de80d216527f74b3ccdfa9f.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eaa492b1d8c56cf0e8e75b21d8cbd6cf',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/e62192aaa0f5a7e236c65d7ba1dd581f.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d5df0ac5b38e229e0128b45432f9062',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/ebe2b413f1319a2739e85eb820d01003.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12abd56ec3c2ac883112e6f15c8167c0',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/f5d203b9bf6ccbedc3ec2eeb7a4106ea.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6c104314c011809a8a42dedcf854b1f',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/2919947bf99d1e5f8a11cd73f65532f7.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '490471452e0b0d55b0b7dcf87504727b',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/7624c5e6dab9ca10d1c1f3ac94798c47.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6afd4f36e4bb1740e67f34154ba85037',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/908c9a7d9e9d2f6f4aa9d36b0133a106.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d1088d875a9d722bab411f72c0bb4f7',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/c118fb43d12c132e8f35fd343f6ab629.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5a61096960479b3b3a2a9064cd18b54',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/f7bdb94c1399bb1eee378daa01896dd9.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f11c7fee8cdcf7273d0a41fbfb33ecc8',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/e584a825e2c442344f6cd75254b0ed1a.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8d2397c65ec8bde44cb7949471fdd39',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/c93c1365d4602b206f58984cb1206733.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91b0b9c6e62edceecdb8acfe0c1298ce',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/2b711f595330b37ae2c8f5d56caee9a8.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cae696b6f14c1cc2083afd436129d6db',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/6ecde96c4675a37c84f21846b6d3258f.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '302524b9a9ea263a6a6f32365de86786',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/d7e9056a0fb589fa1ca098260a87504c.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88723f1e50ea3a57e38dd2b0f87c28c1',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/584d7f9447a9a7e85f223e26827ed7ed.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f510143e779afa0c257406d11bb4c846',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/61503c43e1993b84175b9a9a7a58733f.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b9bd63d5b6649cf853622315657875e',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/10d17d1cabc3f8024a9460a2a782ea72.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a934a9d5af8f8a648533a678f6ade44',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/327af8190b4ebf02a83708ae8c9f9c85.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '379b137769b04abbee48b7563d17e037',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/0df7ba70faad7739b7dda80103b95904.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '399b0335a4e3c4c045ccb97a3cad9b8d',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/caff9ffaea16a6669f7adcc22cdd5267.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1569e044ea7a693445cf0c5af3b6ef7',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/9f322e9374240cd8bb8e75a5775a25fb.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f823b6a964ea26c7ce2d19bd14bb213',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/4ce1496bdc40fc3e189afbeffb73fd7c.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1022330523f6ef33689104dcd83ae1b',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/99dd72ff9ea8de5e89308635354a3f4d.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '405e0a5d57d343580aa2c5e9d098358b',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/7fafe9cb3a1fb41eefd4a4453534991c.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73286d3bf9bee0dac167db4ea8d69e45',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/899104514a07845a756ee0f1a8ada78f.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc9ef0f5f1e5805dcdb82b3fe6107449',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/98d3c3add00148006e16e95b49dddaaf.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f69a46c44f7dd7899fcd19e52f770d9',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/a9942bac08a79a98d6bc9107ffa291c6.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42e0aa5cbc6046b896923e800ad69ef4',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/a6cf079ef9b54fb54feff26ea230a4d1.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0efd50f774b71c188983f90187725e08',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/9073511ef8f3bfd95cd17aec0a431ee1.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2c7b9f3194a3767b58181333fd36588',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/2b694bb1494daf0399402efb11cdfe0c.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6ea2ca7b02b8f98f4493b8cf476fc2e',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/d2d05babc529e7587411eb442b0bbd37.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02caf26210c2b97958df363176bcda92',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/44e21ff92bf0dfdada30043358eedbb4.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e617361c83ae72068e3d92396018c88f',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/ac0335940ff66838cdf6103cf267b35b.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a8d8ec8af43f643097530e93384a15b',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/5421cb32c0fd09c2eac0c58aa0d70a74.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28480c5427db5bd11655985ae5b3dc9c',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/8cb89221214841dd7de39d4655637ec2.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '563cd1a410568850430262538d801a1d',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/0dfa381f2adef24e70120bf72cff4b01.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '681a5b64cbfc5bbcbfdb50338eb8dda6',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/7c5c9927b24f106a3b70b671d2aceb85.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16fda59ddcae9f128b30af0dec3e9db6',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/6b8824957f869015cf4674b00c1f3713.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea4f81fa01c7aab3147d146366a095b7',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/bc2c82be963e717bf22fb89ee6ec9fa9.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33404280faf41d6e60dff91ef7e51208',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/97fb2d6319e0829bbd33fe700d26475a.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07be5734c37b59ec1e11cc308f56de2d',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/aedcc7128536132a40454177d5c9bd89.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbb560f6744a9b12ebecd8e3a8b58e86',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/e8ffb8f00b7e8208c48249c279d98a89.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6d344395c6a49cf35336046678046ec',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/d20d2f17a6d1133171aee7f5710f831e.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fd02447aa278ab8a349f6b3c9f53278',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/8e3fba0a6f8a62158d1345998b089a5a.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31a642eb4d1497c17eb09930385b90ba',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/c9676b6d3ea5892f70dc42507849103c.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4167b4f12d225bd31209be1f697141a',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/127f83a56992051059484be0869ecced.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15a9931a82a6fa00504f138198f1b88d',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/c35645c7a2e093d76c61b1077f1b1f7c.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f33d85e72184f9a213c18009d2b6b32',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/aaddc791c60f3e5c70e6d07c3d1dc37b.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac8bccf960ef11d2487157ef32252b2d',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/1771443819f3fa2eb1e0d39dbc239cc3.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '370a00d338efa8efa4d5e75f4478e14e',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/092aeeebc8255728c008ea362ae7e293.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3ac32aeeed3a06dde561c129bc17f9b',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/322e9bb9585d94ebbfe20b56c911fa11.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e06f49bfefd9aa102d958a8e135d38fb',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/4deeb07ccdf93a89a040de46fee65bf2.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2f245cf0c29522fd9c1f82286bde3cd',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/ea05817bf11a163d89c66810a9b89746.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'feb34c6cfc5d4e354b698d218f00e22b',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/ba7d75d141586343ce2bda0e66a7946d.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '774780f9c16d3cc9609787471d0e3a98',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/a7e5ca6a0f5498a197cdcad13ce6a052.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e8e3e5ee48178203c2c21a8aafac30e',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/d99c951c2c16dfea69bb60d00dfe2a2c.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3827857980b15d0d42958d015482f3eb',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/79c6db5179c66e9c8a8b09b2f9b995e7.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4aafeadbade4fd25683868cbe8ff804',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/98a5067214aa5fe5ccd69950431e3733.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bd1c8796523241b87e02c2ab30c3b6e',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/b832803a64d109670a761bd77206d3c6.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b66a9fcbf37d8cd4111d4133a95c56b',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/23b42bc5af907f237444ec530db35e1b.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5088681d8fea13bb8d3aef5b9e6c4db8',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/b38d703027f7cdf858c181aabcd65725.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '255943fa273a0350e8dfa9173b2de982',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/41266cedb3a7193e1546747c36bf97a0.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28ac482862df30e672119b4d7754055f',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/54104cd494808610d5d84e7b68aa5eb8.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bc3c061499d82e0c0f8efe9c83c5e07',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/8ce57147be7f5430346c24d380a2eb8d.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faa5d36b3e0ea345f4bbe83f6e9ebe76',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/34c6dd6b9a9c538b90030ae2807bb854.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5f492946caaf58f212d1882552977c4',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/0f9ee4696944e0305a87fac0709a6c99.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cd1300d73df6615d2b546fd3ca779d9',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/2fdcec9d1825dde78b63aad11dd70fdd.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f7afbab0418f63a1a44c2260ae0721a',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/0b7844b63929ca6b5a197fc5e2b22177.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bacb6a576c079c4134e97dc98a09c113',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/f63f7f60a784c91536716f1e05be913b.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc1d73555bd13e4c19042b80efa51996',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/94078771ac96cf113433ba50de43c8f4.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '647735ed117ea95a066f24971d4e6e4d',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/1b1013d158c439442172e87a37c9aea7.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ef6b65f74ed40c608be3362a2ffc0d3',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/744e696a18bb30d72ba11238290c1893.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '306d432e39fab6b239ba0b7a779762df',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/ef1d6625fc451ccf940d671785ef5cbb.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70931aedd39887dcd6937a247bafd2c6',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/d82c7a7cdfd098456df697f3d4d2ae96.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62ed4d53923e1ecd2cafd1f0fe3dff4b',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/556a40b9d46379da8fadf18a0f68c4a6.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f034d6cf4343f386928ebdbbc0e3230',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/63bff4060ffdcea724f19d070d97149a.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0431914dec29d175bf3fa68368bba7a8',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/791b63b4405d1adb057a36c0724b58d7.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d386a6cc5f2753b53c9ddd935e5bcfe',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/c798cfcb38c7a71ea98c40b2d60f6351.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7390dd0bba578b8adf849af5c581007',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/34e49f62eca8208539ff4ef37d7058e4.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e5f1c2645116d50539c29695453a8f3',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/69ac392d975959e96219a56f611865a4.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fe6c7e5c945c348c44c502ec514fe9f',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/4eb501a6cf5c9c577122a739c154b16b.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dda3bebdf547863906ae6e2a09bbee7',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/79363ad480d4e668fe77772ae3b72bb0.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1401b9eac4b4984672a1e7f320666e3',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/d68b0912c5f08d7694a71453f5946e8c.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '388fe02f64d6aa421f4fc9d2987628d4',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/7561acaf6378e13e6be85a996495408d.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd43ee49bb8b3d263cfccd78ef0cc0539',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/c30613c9c33472abcd1c7b24944338d5.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'c9ff298e3bf0ffe4e32fa9556de64a0c',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/1f17369d386d9e8de406117148fd7a01.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '4b278dce4f36cefd348d835dc91cdf3c',
      'native_key' => 1,
      'filename' => 'modUserGroup/104e0d56d260c529c8f53c7220fc2007.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'ab1b0f75fedd5867b2f057b36b1065ac',
      'native_key' => 1,
      'filename' => 'modDashboard/a2b0abf2ccaaa84d908edd1e8b6877c1.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'daf83e6be5bd376d28d807f06ecefd0f',
      'native_key' => 1,
      'filename' => 'modMediaSource/1b96fc13f6c105216da939af7b27b7a9.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'dc4c586b4250ca05663124752d7dca9a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b8d5eb76f947a7f92fa1f47c1097c158.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '598c61f1bfb0decb2df53f32651ed47e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/5af8626849be75a958fdd40b8db5bc5d.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '1d80ef4da33d30265ea6565c145e90fe',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/419c0a80e121f6f1a993d6607f689b6a.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8cb2972f5daa52535a67a2c913759993',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/168e3a210527b68d7f48cd39e028daab.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '0df5e8d1177c3f243ba497c91f149652',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ae4010e4911d900a4a8d3377819e26f9.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'c331e8523fffc94c31fd20477827d2b7',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/8b6d90396a97cb5b5e98a931d0469ac6.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'a0923dc3670bfd599399b9a6f27d9144',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/3e59071218436c06da3abd7dca80b47c.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2b7ae1425e743016621b8b2fc90b5872',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/93043e53626a8a5bcd4a366a01590ae0.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'b4e287da37c9d7aad3d3f265e0afd952',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a3ee16ae0a4e9ec0ab2a6af1f35cbaa2.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '632638502d804668e7709512773eabb3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ce14cba8ad3092d1a28b7c648c811009.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'af25e07eb32abaa1c9d07205c3ff6d56',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/83f77aa2183ff443ffab7eea6fc083d0.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'cc60303310c2bec090c583224e3318f1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a0aa9d09d0f5fde11ef26ac7751a6831.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'b794c12d4b63e68c7377e68247e4f4c8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/592ee338df3007067bf015748c7d1bf7.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '793dd7278091da2a007205c1343069ca',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/dbee348fb02b9aa2400bc45864b1a435.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '151de4b73468bb3b0911e74e82159f9e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8ee9de3c334e4a5118ae7d0c151e2374.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a71b1e2f972ac0cdbe64a50a95252aab',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/21c1a4b482187c8d5c6497b4596e498e.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '37fc095580756c8db18a71969a3a769d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2e661c2c8ac9c50e38bfc9836c2a44f2.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c506daa550cdea32d220fa395216f54a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c4b9902ccaf7c7acf5523e21622343bb.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd419f47bc9c3c496bab68a3900c961d4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d97e18190d455945552e8e34248fae33.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2e8605fa1f2c6725cf83396d86e5faa1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bb3b8a904c2e4a28e0f76cf6c527ae62.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4935e9a007520960ecd659c3a34a6c4e',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/6afa6f6c048b7db909fd010d82db01b8.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'edb58916b39e21b6d548564c3b074b67',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/79b4b76e92b09df1b5eb661bdf0c2da1.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3253647eca4d46e35c80acea603439df',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/31f5c6ef935e724f1c27a1b0606ae079.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '72326fb42d4294ce208532ad94ed7953',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/c24a82bf2184ee56cb35e17ee0d3f59a.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd18d97cfff58ac2f5d76b2020e280d1b',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/1eed3b226b59965a2aad446160ee355d.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8cff123b0630e54fb575ba212a77d937',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/90ccfdb0c9f8b82ee1f3bded22df3ccc.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e42fbfeaf15e9aa94b2943d0d2c98bf7',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/b2e5fa9dfb09c6422fd093a96e701eb1.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5fb1c1e2c1a6b6eb153311f2266497de',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/6d6127882e2eaaff2a2f4f37c00b2505.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '643d5930fe7d172833f2fd0f50e57a19',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/1981ae4b1251b343bbc0a9b1b70d1472.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '752eeed8cc671eceee7d7d1fe470ae77',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/97424743cf0c6819d83edd418c1b8ee1.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6339a0fbef87e6804ce912a33fd4f4bd',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/c5b756af746f1f91042b7f03eca7aa13.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a7e5ebe2484850e99c034bdb531ca971',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/e0f186c851dd78c55afec18874bff10d.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'b121500f2b52ddf03d69bd70cbca9dca',
      'native_key' => 'web',
      'filename' => 'modContext/b120b4fb2a0f33b29e22677ce650c75b.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'de209c54a5cde1daf2348322c7dc0dd6',
      'native_key' => 'mgr',
      'filename' => 'modContext/c67998df2bbb523c9b20e06d02ab14a5.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '25fe7b96f5a1e04b53ce3a9e81d229e7',
      'native_key' => '25fe7b96f5a1e04b53ce3a9e81d229e7',
      'filename' => 'xPDOFileVehicle/6532dc85c9985f587fc9dd626773ab5f.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e2f591d62c7e1012410152f17c5d4bd6',
      'native_key' => 'e2f591d62c7e1012410152f17c5d4bd6',
      'filename' => 'xPDOFileVehicle/98abb70e7d513bcef6c52bcfdf4617ed.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6f5f001ea23eb3efd26b0eec6cc49311',
      'native_key' => '6f5f001ea23eb3efd26b0eec6cc49311',
      'filename' => 'xPDOFileVehicle/703a13f61ce96518b6f7b0b7e53193db.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'dd70ba4480b8925385293aa7bb1d6ce4',
      'native_key' => 'dd70ba4480b8925385293aa7bb1d6ce4',
      'filename' => 'xPDOFileVehicle/bd8804a6b378049818ba539dd203696b.vehicle',
    ),
  ),
);