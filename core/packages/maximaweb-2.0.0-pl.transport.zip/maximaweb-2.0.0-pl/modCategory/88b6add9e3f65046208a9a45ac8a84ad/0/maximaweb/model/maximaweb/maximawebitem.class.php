<?php

/**
 * @package maximaweb
 */
class maximawebItem extends xPDOSimpleObject
{
}