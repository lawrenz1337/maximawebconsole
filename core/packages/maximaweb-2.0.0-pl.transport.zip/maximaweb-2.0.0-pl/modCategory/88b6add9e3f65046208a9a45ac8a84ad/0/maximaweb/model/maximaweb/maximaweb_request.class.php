<?php
class maximaweb_request extends xPDOSimpleObject {}