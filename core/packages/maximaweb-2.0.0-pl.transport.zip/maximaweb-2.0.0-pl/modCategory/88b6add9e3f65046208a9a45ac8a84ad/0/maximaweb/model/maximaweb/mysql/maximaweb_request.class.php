<?php
require_once (dirname(__DIR__) . '/maximaweb_request.class.php');
class maximaweb_request_mysql extends maximaweb_request {}